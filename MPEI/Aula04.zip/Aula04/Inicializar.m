function B = Inicializar(n)
% Inicializa o filtro de Bloom (vetor a zeros)
    B = zeros(1, n, 'uint8');
end